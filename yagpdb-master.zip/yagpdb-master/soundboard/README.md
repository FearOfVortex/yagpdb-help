# Soundboard

Soundboard plugin for YAGPDB

Folder structure:

### Sounds waiting:
soundboard/queue/guildid/soundhash.extension

### Transcoded sounds
soundboard/ready/guildid/soundhash.dca
