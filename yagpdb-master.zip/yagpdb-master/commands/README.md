The commands plugin handles the configuration of the global command settings.
