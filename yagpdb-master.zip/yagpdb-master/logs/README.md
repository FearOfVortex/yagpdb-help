# Logs

The logs plugin logs certain information from servers.


 - Can store a subset of the message history with deleted messages
 - Username changes
