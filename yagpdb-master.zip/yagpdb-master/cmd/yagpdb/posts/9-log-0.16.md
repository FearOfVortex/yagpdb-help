    {
        "author": "jonas747",
        "date": "6th Nov 2016",
        "title": "Version 0.16"
    }

 - **Added HTTPS via lets encrypt!**
 - **New plugin: Automoderator**(beta), this plugin lets you define certain rules and auto punishment for breaking those rules
 - **New plugin: AutoRole**(beta), this plugin can assign people a role on joins, and also using the command (if they already had the role it will get removed): `-role rolename`
 - **New Plugin: Logs**(beta), use `logs (number of messages)` to save the n last messages (similar to how hastebin worked but locally hosted on yagpdb instead)
 - **Updated moderation plugin**. You can now specify a mute role, and give people the role with the commands `mute` and `unmute`
 - New/changed roles and channels now instantly shows up in the control panel!
 - More tweaks to the website!
 - Fixed a bug where streamer plugin would fail to remove streaming status when the status has them not playing any game
