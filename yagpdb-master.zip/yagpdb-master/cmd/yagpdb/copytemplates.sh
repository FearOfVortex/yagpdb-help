#!/bin/bash

mkdir -p templates/plugins

cp ../../*/assets/* templates/plugins/

# cp ../../automod/assets/* templates/plugins/
# cp ../../automod_legacy/assets/* templates/plugins/
# cp ../../autorole/assets/* templates/plugins/
# cp ../../commands/assets/* templates/plugins/
# cp ../../customcommands/assets/* templates/plugins/
# cp ../../logs/assets/* templates/plugins/
# cp ../../moderation/assets/* templates/plugins/
# cp ../../notifications/assets/* templates/plugins/
# cp ../../reddit/assets/* templates/plugins/
# cp ../../reputation/assets/* templates/plugins/
# cp ../../rolecommands/assets/* templates/plugins/
# cp ../../serverstats/assets/* templates/plugins/
# cp ../../soundboard/assets/* templates/plugins/
# cp ../../streaming/assets/* templates/plugins/
# cp ../../youtube/assets/* templates/plugins/
# cp ../../premium/assets/* templates/plugins/