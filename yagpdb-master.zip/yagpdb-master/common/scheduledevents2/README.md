The sucessor of the original scheduled events system for yagpdb that was running on redis, this one however is running on postgres.

The old system did not support things like clustering and was overall a bit messy and unstructured.
