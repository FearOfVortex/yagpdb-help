# Notifications

Simple notifications plugin for YAGPDB.

Will provide general notifications in a server for the following events:

 - User join
 - User leave
 - Topic changed
 - Message pinned
