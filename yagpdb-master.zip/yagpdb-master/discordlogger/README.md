# Logs errors and bot leaves/joins to a channel
