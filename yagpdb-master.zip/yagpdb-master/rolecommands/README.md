Plugin that allows users to assign roles to themsleves

- role options
    + names
    + group
    + require-roles
    + ignore-roles
    + allow-take-off-role

- group options
    + name
    + require-roles
    + ignore-roles
    + mode
        * single
            - auto-take-away
            - require-one
        * multi
            - max-amount
            - min-amount
        * none
