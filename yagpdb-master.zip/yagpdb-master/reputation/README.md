# Reputation

This YAGPDB plugin adds a reputation system.

Provides the `+/giverep`, `rep` and `toprep` commands.
